package com.kcs.socialsync

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
